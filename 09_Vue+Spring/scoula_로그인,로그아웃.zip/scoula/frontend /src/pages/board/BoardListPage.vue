<script setup></script>

<template>
  <h1>게시글목록 페이지</h1>
</template>
