<script setup></script>

<template>
  <h1>프로필 페이지</h1>
</template>
