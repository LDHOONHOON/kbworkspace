<script setup></script>

<template>
  <h1>비밀번호변경 페이지</h1>
</template>
