import{_ as e,o as c,d as r}from"./index-BtjvC4nq.js";const t={};function n(o,a){return c(),r("h1",null,"사진목록 페이지")}const _=e(t,[["render",n]]);export{_ as default};
