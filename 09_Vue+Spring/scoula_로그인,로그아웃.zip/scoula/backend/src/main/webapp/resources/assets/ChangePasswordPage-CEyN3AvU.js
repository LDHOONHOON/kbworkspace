import{_ as e,o as c,d as n}from"./index-BtjvC4nq.js";const o={};function r(a,s){return c(),n("h1",null,"비밀번호변경 페이지")}const _=e(o,[["render",r]]);export{_ as default};
