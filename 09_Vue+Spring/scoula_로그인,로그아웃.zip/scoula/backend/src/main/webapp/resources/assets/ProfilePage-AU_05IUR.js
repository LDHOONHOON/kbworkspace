import{_ as e,o as c,d as o}from"./index-BtjvC4nq.js";const r={};function n(t,a){return c(),o("h1",null,"프로필 페이지")}const _=e(r,[["render",n]]);export{_ as default};
