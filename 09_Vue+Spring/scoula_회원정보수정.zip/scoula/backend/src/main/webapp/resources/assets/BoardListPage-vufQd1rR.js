import{_ as e,o as c,d as o}from"./index-COqEJjR9.js";const r={};function t(n,a){return c(),o("h1",null,"게시글목록 페이지")}const _=e(r,[["render",t]]);export{_ as default};
