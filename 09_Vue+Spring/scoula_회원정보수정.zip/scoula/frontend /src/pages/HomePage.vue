<script setup></script>

<template>
  <h1>첫번째 페이지</h1>
</template>
