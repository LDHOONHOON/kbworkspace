<script setup></script>

<template>
  <h1>여행목록 페이지</h1>
</template>
