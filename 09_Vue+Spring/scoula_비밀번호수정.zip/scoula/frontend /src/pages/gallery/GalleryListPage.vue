<script setup></script>

<template>
  <h1>사진목록 페이지</h1>
</template>
